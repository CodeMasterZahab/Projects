<!-- README – Mood-Based Chatbot Using if-else
🧠 Project Overview

This project is a simple rule-based chatbot built completely using Python and basic if–elif–else conditions.
The chatbot can detect the user's mood and respond accordingly.

This project demonstrates:

Input/output loops

Rule-based responses

Mood classification using keywords

Basic NLP concepts using string matching

🎯 Objective

To create a chatbot that interacts with users and responds based on their feelings using simple conditional statements.

🛠️ Tools & Technologies

Python 3

Tkinter (GUI version)

pyttsx3 (voice output)

SpeechRecognition (voice input for optional version)

🚀 Features

Text-based conversation

Mood detection

GUI version with buttons + chat window

Voice-enabled chatbot (optional)

Quit command: “bye” -->