import speech_recognition as sr
import pyttsx3

engine = pyttsx3.init()

def speak(text):
    print("Bot: ",text)
    engine.say(text)
    engine.runAndWait()

recognizer = sr.Recognizer()
speak("Hello! I am your voice chatbot Say something ")

while True:
    try:
        with sr.Microphone as mic:
            print("Listening")
            audio = recognizer.listen(mic)
            user = recognizer.recognize_google(audio).lower()
            print("You: ",user)

        if "bye" in user:
            speak("Goodbye! Take care.")
            break

        elif "hello" in user or "hi" in user:
            speak("Hello! How are you feeling today?")

        elif "happy" in user:
            speak("That's wonderful to hear!")

        elif "sad" in user:
            speak("I'm here for you. Everything will be okay.")

        elif "angry" in user:
            speak("Take a breath and relax. You're strong.")

        elif "bored" in user:
            speak("Here's a fun fact: Octopuses have three hearts!")

        else:
            speak("I'm not sure I understand. Could you repeat?")

    except:
        speak("I couldn't hear you properly. Please try again.")