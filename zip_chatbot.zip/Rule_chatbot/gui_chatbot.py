import tkinter as tk

def send_message():
    user_input = entry.get().lower()
    chat.insert(tk.END, f"You: {user_input}\n")
    entry.delete(0, tk.END)

    if "bye" in user_input:
        chat.insert(tk.END, "Bot: Goodbye! Take care 😊\n")
        return

    elif "hi" in user_input or "hello" in user_input:
        reply = "Hi there! How are you feeling today?"

    elif "happy" in user_input:
        reply = "That's awesome! Keep smiling 😄"

    elif "sad" in user_input:
        reply = "I'm here for you. You're not alone 💙"

    elif "angry" in user_input:
        reply = "Calm down… try deep breathing 🔥🙂"

    elif "bored" in user_input:
        reply = "Fun fact: Honey never spoils! 🍯"

    elif "tired" in user_input:
        reply = "You should take some rest 😴"

    else:
        reply = "Hmm… I'm still learning. Tell me more!"

    chat.insert(tk.END, f"Bot: {reply}\n")


root = tk.Tk()
root.title("MoodBot - Chatbot")
root.geometry("600x500")  # Bigger window for better layout

# Chat box
chat = tk.Text(root, height=20, width=70)
chat.pack(pady=20)

# Default welcome message
chat.insert(tk.END, "Bot: Hey there! How can I help you? 😊\n")

# Bottom frame for centering input + button
bottom_frame = tk.Frame(root)
bottom_frame.pack(pady=10)

# Wider entry box + centered
entry = tk.Entry(bottom_frame, width=45, font=("Arial", 12))
entry.grid(row=0, column=0, padx=10)

send_btn = tk.Button(bottom_frame, text="Send", command=send_message, width=10)
send_btn.grid(row=0, column=1)

root.mainloop()