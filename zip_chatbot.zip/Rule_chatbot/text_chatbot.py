print ("🤖Chatboat: Hello!! I'm a MoodBot. Type 'bye' to exit ")

while True:
    user  = input("You: ").lower()
     
    if user == "bye":
        print("🤖Chatboat: Goodbye! Take care 😊")
        break
    
    elif "hi" in user or "hello" in user:
        print("🤖Chatboat: Hi there! How are you feeling today?")
    elif "happy" in user:
        print("🤖Chatboat: Thats awesome! Keep smiling 😊 ")
    elif "sad" in user:
        print("🤖Chatboat: I'm here for u .You're not alone 💙")
    elif "angry" in user:
         print("🤖Chatboat: Relax everything will be okay 🔥🙂")
    elif "bored" in user:
         print("🤖Chatboat: Want a fun fact? Honey never spoils! 🍯")
    elif "tired" in user:
         print("🤖Chatboat: You should take some rest 😴")
    else:
        print("🤖 Chatbot: Hmm… I'm still learning. Tell me more!")