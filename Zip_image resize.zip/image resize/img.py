from tkinter import filedialog
from PIL import Image

# select image
img_path = filedialog.askopenfilename(title="Select Image")
img = Image.open(img_path)

# enter size
new_width = int(input("Width: "))
new_height = int(input("Height: "))

# resize
resized = img.resize((new_width, new_height))

# save
resized.save("resized_output.jpg")
print("Saved as resized_output.jpg")
